﻿
$ErrorActionPreference = 'Stop'
$sheets = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String('WwB7ACIAbgBhAG0AZQAiADoAIAAiAFMAYQBsAGUAcwAiACwAIAAiAGgAZQBhAGQAZQByAHMAIgA6ACAAWwAiAFAAcgBvAGQAdQBjAHQAIgAsACAAIgBRAHQAeQAiAF0ALAAgACIAcgBvAHcAcwAiADoAIABbAFsAIgBBACIALAAgACIAMQAwADAAIgBdACwAIABbACIAQgAiACwAIAAiADIAMAAwACIAXQBdAH0AXQA=')) | ConvertFrom-Json

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false
$wb = $excel.Workbooks.Add()

$firstSheet = $true
foreach ($s in $sheets) {
    if ($firstSheet) {
        $ws = $wb.Sheets[1]
        $firstSheet = $false
    } else {
        $ws = $wb.Worksheets.Add()
    }
    $ws.Name = $s.name
    
    if ($s.headers) {
        for ($c = 0; $c -lt $s.headers.Count; $c++) {
            $ws.Cells.Item(1, $c+1).Value = [string]$s.headers[$c]
            $ws.Cells.Item(1, $c+1).Font.Bold = $true
        }
    }
    if ($s.rows) {
        for ($r = 0; $r -lt $s.rows.Count; $r++) {
            for ($c = 0; $c -lt $s.rows[$r].Count; $c++) {
                $ws.Cells.Item($r+2, $c+1).Value = [string]$s.rows[$r][$c]
            }
        }
    }
}

$wb.SaveAs('C:\Users\15041\AppData\Local\Temp\tmpoivn220o/data.xlsx')
$wb.Close()
$excel.Quit()
Write-Output 'SUCCESS'
